from pyperp.providers import ApiProvider
from web3 import Web3 
from eth_account import Account
import logging
from pyperp.common.types import (
    GasParams
)

class Vault:
    def __init__(
        self,
        provider: ApiProvider
    ):
        self._provider = provider
        self.account = self._provider.account
        self.logger = logging.getLogger("Vault")
        
        self.logger.info("Loading Vault contract")
        vault_meta = self._provider.load_meta("Vault")
        self.vault = self._provider._api.eth.contract(
            address=vault_meta["address"],
            abi=vault_meta["abi"]
        )
        self.logger.info("Vault contract loaded")

        self.logger.info("Loading USDC contract")
        usdc_meta = self._provider.load_meta("USDC")
        self.usdc = self._provider.api.eth.contract(
            address=usdc_meta["address"],
            abi=usdc_meta["abi"]
        )
        self.logger.info("USDC contract loaded")


    def approve_vault_to_use_usdc(
        self,
        gas_params: GasParams
    ):
        '''
        Approve Vault contract to use USDC
        Arguments:
        gas_params: GasParams object
        '''
        logging.info("Approving ClearingHouse to use USDC")
        nonce = self._provider.api.eth.get_transaction_count(
            self.account.address
        )

        tx_params = {
            'nonce': nonce,
            **(gas_params.to_dict())
        }
        
        tx = self.usdc.functions.approve(
            self.vault.address,
            2**256-1
        ).buildTransaction(tx_params)

        signed_tx = self._provider.api.eth.account.sign_transaction(
            tx, self.account.key.hex()
        )

        tx_hash = self._provider.api.eth.send_raw_transaction(
            signed_tx.rawTransaction.hex()
        )

        receipt = self._provider.api.eth.wait_for_transaction_receipt(
            tx_hash
        )

        return receipt

    def deposit(
        self,
        token: str,
        amount_x10_D: int,
        gas_params: GasParams
    ):
        nonce = self._provider.api.eth.get_transaction_count(
            self.account.address
        )

        tx_params = {
            'nonce': nonce,
            **(gas_params.to_dict())
        }

        tx = self.vault.functions.deposit(
            token,
            amount_x10_D
        ).buildTransaction(tx_params)

        signed_tx = self._provider.api.eth.account.sign_transaction(
            tx, self.account.key.hex()
        )

        tx_hash = self._provider.api.eth.send_raw_transaction(
            signed_tx.rawTransaction.hex()
        )

        receipt = self._provider.api.eth.wait_for_transaction_receipt(
            tx_hash
        )

        return receipt

    def deposit_for(
        self,
        to: str,
        token: str,
        amount_x10_D: int,
        gas_params: GasParams
    ):
        nonce = self._provider.api.eth.get_transaction_count(
            self.account.address
        )
        
        tx_params = {
            'nonce': nonce,
            **(gas_params.to_dict())
        }


        tx = self.vault.functions.depositFor(
            to,
            token,
            amount_x10_D
        ).buildTransaction(tx_params)

        signed_tx = self._provider.api.eth.account.sign_transaction(
            tx, self.account.key.hex()
        )

        tx_hash = self._provider.api.eth.send_raw_transaction(
            signed_tx.rawTransaction.hex()
        )

        receipt = self._provider.api.eth.wait_for_transaction_receipt(
            tx_hash
        )

        return receipt

    def withdraw(
        self,
        token: str,
        amount_x10_D: int,
        gas_params: GasParams
    ):
        nonce = self._provider.api.eth.get_transaction_count(
            self.account.address
        )

        tx_params = {
            'nonce': nonce,
            **(gas_params.to_dict())
        }

        tx = self.vault.functions.withdraw(
            token,
            amount_x10_D
        ).buildTransaction(tx_params)

        signed_tx = self._provider.api.eth.account.sign_transaction(
            tx, self.account.key.hex()
        )

        tx_hash = self._provider.api.eth.send_raw_transaction(
            signed_tx.rawTransaction.hex()
        )

        receipt = self._provider.api.eth.wait_for_transaction_receipt(
            tx_hash
        )

        return receipt

    def get_settlement_token(self):
        return self.vault.functions.getSettlementToken(
        ).call()

    def decimals(self):
        return self.vault.functions.decimals().call()
    
    def get_total_debt(self):
        return self.vault.functions.getTotalDebt().call()

    def get_clearing_house_config(self):
        return self.vault.functions.getClearingHouseConfig().call()
    
    def get_account_balance(self):
        return self.vault.functions.getAccountBalance().call()

    def get_insurance_fund(self):
        return self.vault.functions.getInsuranceFund().call()

    def get_exchange(self):
        return self.vault.functions.getExchange().call()

    def get_clearing_house(self):
        return self.vault.functions.getClearingHouse().call()

    def get_free_collateral(
        self,
        trader: str
    ):
        return self.vault.functions.getFreeCollateral(
            trader
        ).call()

    def get_balance(
        self,
        trader: str
    ):
        return self.vault.functions.getBalance(trader).call()

    def get_free_collateral_by_ratio(
        self,
        trader: str,
        ratio: int
    ):
        return self.vault.functions.getFreeCollateralByRatio(
            trader, ratio
        ).call()